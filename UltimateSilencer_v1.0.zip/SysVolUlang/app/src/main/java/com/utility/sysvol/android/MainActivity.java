package com.utility.sysvol.android;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.widget.*;
import android.graphics.Color;
import android.view.View;
import android.media.AudioManager.OnAudioFocusChangeListener;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    
    private AudioManager audioManager;
    private Handler handler;
    private Runnable volumeKiller;
    private boolean isActive = false;
    private ToggleButton toggleButton;
    private TextView logText;
    private TextView targetInfo;
    private EditText packageInput;
    private Button saveButton;
    private OnAudioFocusChangeListener audioFocusListener;
    private ScrollView scrollView;
    
    private String currentTargetPackage = "";
    private String currentTargetName = "";
    
    private static final String PREFS_NAME = "SilencerPrefs";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // ========== UI ==========
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(25, 25, 25, 25);
        layout.setBackgroundColor(Color.BLACK);
        
        // Title
        TextView title = new TextView(this);
        title.setText("⚡ ULTRA SILENCER ⚡");
        title.setTextColor(Color.RED);
        title.setTextSize(20);
        title.setPadding(0, 0, 0, 5);
        title.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        layout.addView(title);
        
        // Subtitle
        TextView sub = new TextView(this);
        sub.setText("Pre-emptive Strike Mode");
        sub.setTextColor(Color.YELLOW);
        sub.setTextSize(10);
        sub.setPadding(0, 0, 0, 15);
        sub.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        layout.addView(sub);
        
        // Input section
        TextView inputLabel = new TextView(this);
        inputLabel.setText("📦 PACKAGE NAME:");
        inputLabel.setTextColor(Color.WHITE);
        inputLabel.setTextSize(12);
        inputLabel.setPadding(0, 5, 0, 5);
        layout.addView(inputLabel);
        
        packageInput = new EditText(this);
        packageInput.setHint("Contoh: net.sid.alguik_v1");
        packageInput.setTextColor(Color.WHITE);
        packageInput.setHintTextColor(Color.GRAY);
        packageInput.setBackgroundColor(Color.DKGRAY);
        packageInput.setPadding(15, 12, 15, 12);
        layout.addView(packageInput);
        
        // Save button
        saveButton = new Button(this);
        saveButton.setText("💾 SAVE TARGET");
        saveButton.setTextColor(Color.BLACK);
        saveButton.setBackgroundColor(Color.GREEN);
        saveButton.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTarget();
            }
        });
        layout.addView(saveButton);
        
        // Target info
        targetInfo = new TextView(this);
        targetInfo.setTextColor(Color.CYAN);
        targetInfo.setTextSize(12);
        targetInfo.setPadding(0, 10, 0, 10);
        layout.addView(targetInfo);
        
        // Toggle button
        toggleButton = new ToggleButton(this);
        toggleButton.setTextOff("🔇 OFF");
        toggleButton.setTextOn("🔪 ULTRA SILENT ON");
        toggleButton.setTextSize(14);
        toggleButton.setPadding(0, 15, 0, 15);
        toggleButton.setEnabled(false);
        toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    activateWarMode();
                } else {
                    deactivateWarMode();
                }
            }
        });
        layout.addView(toggleButton);
        
        // Log area with scroll
        TextView logLabel = new TextView(this);
        logLabel.setText("📋 LIVE LOG:");
        logLabel.setTextColor(Color.WHITE);
        logLabel.setTextSize(11);
        logLabel.setPadding(0, 15, 0, 5);
        layout.addView(logLabel);
        
        scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(Color.DKGRAY);
        scrollView.setPadding(10, 10, 10, 10);
        scrollView.setMinimumHeight(280);
        
        logText = new TextView(this);
        logText.setTextColor(Color.GREEN);
        logText.setTextSize(10);
        logText.setPadding(5, 5, 5, 5);
        scrollView.addView(logText);
        
        layout.addView(scrollView);
        
        setContentView(layout);
        
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        handler = new Handler();
        
        // AUTO CLEAR LOG SAAT APP DIBUKA!
        if (logText != null) {
            logText.setText("");
        }
        
        loadSavedTarget();
        addLog("✅ ULTRA SILENCER READY!");
        addLog("💀 Mode: Pre-emptive Strike");
        addLog("📌 Masukkan package name lalu tekan SAVE");
    }
    
    private void saveTarget() {
        final String pkg = packageInput.getText().toString().trim();
        if (pkg.isEmpty()) {
            addLog("❌ Package name kosong!");
            return;
        }
        
        addLog("🔍 Mengecek: " + pkg);
        
        if (isAppInstalled(pkg)) {
            currentTargetPackage = pkg;
            currentTargetName = getAppName(pkg);
            
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            prefs.edit().putString("target_pkg", currentTargetPackage).apply();
            
            targetInfo.setText("🎯 TARGET: " + currentTargetName);
            toggleButton.setEnabled(true);
            
            addLog("✅ TARGET SAVED!");
            addLog("📱 App: " + currentTargetName);
            addLog("📦 Package: " + currentTargetPackage);
            addLog("💡 Tekan toggle ON untuk memulai!");
        } else {
            addLog("❌ App TIDAK TERINSTALL!");
            addLog("💡 Package: " + pkg + " tidak ditemukan");
        }
    }
    
    private void loadSavedTarget() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String pkg = prefs.getString("target_pkg", "");
        if (!pkg.isEmpty()) {
            if (isAppInstalled(pkg)) {
                currentTargetPackage = pkg;
                currentTargetName = getAppName(pkg);
                targetInfo.setText("🎯 TARGET: " + currentTargetName);
                packageInput.setText(pkg);
                toggleButton.setEnabled(true);
                addLog("📀 Loaded saved target!");
                addLog("🎯 " + currentTargetName + " (" + currentTargetPackage + ")");
            } else {
                addLog("⚠️ Saved target not found: " + pkg);
                addLog("💡 Install app atau ganti target");
            }
        }
    }
    
    private void activateWarMode() {
        if (currentTargetPackage.isEmpty()) {
            addLog("❌ Target belum diset!");
            toggleButton.setChecked(false);
            return;
        }
        
        isActive = true;
        
        addLog("\n⚔️⚔️⚔️ WAR MODE ACTIVATED! ⚔️⚔️⚔️");
        addLog("===================================");
        addLog("🎯 Target: " + currentTargetName);
        addLog("📦 Package: " + currentTargetPackage);
        
        // Lock semua stream
        forceMute();
        addLog("✅ All streams muted");
        
        // Hijack audio focus
        hijackAudioFocus();
        addLog("✅ Audio focus hijacked");
        
        // Loop cepat
        volumeKiller = new Runnable() {
            @Override
            public void run() {
                if (isActive) {
                    forceMute();
                    handler.postDelayed(this, 30);
                }
            }
        };
        handler.post(volumeKiller);
        
        addLog("⚡ Loop attack: 30ms interval");
        addLog("💀 " + currentTargetName + " IS SILENCED!");
        addLog("⚠️ Minimize app, jangan di close!");
    }
    
    private void forceMute() {
        try {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            audioManager.setStreamVolume(AudioManager.STREAM_SYSTEM, 0, AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            audioManager.setStreamVolume(AudioManager.STREAM_RING, 0, AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, 0, AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            audioManager.setStreamVolume(AudioManager.STREAM_NOTIFICATION, 0, AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE);
            audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
        } catch (Exception e) {}
    }
    
    private void hijackAudioFocus() {
        try {
            audioFocusListener = new OnAudioFocusChangeListener() {
                @Override
                public void onAudioFocusChange(int focusChange) {
                    if (isActive) {
                        audioManager.requestAudioFocus(this,
                            AudioManager.STREAM_MUSIC,
                            AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE);
                    }
                }
            };
            
            audioManager.requestAudioFocus(audioFocusListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE);
            
        } catch (Exception e) {}
    }
    
    private void deactivateWarMode() {
        isActive = false;
        if (volumeKiller != null) {
            handler.removeCallbacks(volumeKiller);
        }
        if (audioFocusListener != null) {
            try {
                audioManager.abandonAudioFocus(audioFocusListener);
            } catch (Exception e) {}
        }
        
        addLog("\n🛑 WAR MODE DEACTIVATED");
        addLog("🔊 " + currentTargetName + " can make sound again");
        addLog("💡 Log akan auto clear saat app ditutup");
    }
    
    private boolean isAppInstalled(String pkg) {
        try {
            getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
    
    private String getAppName(String pkg) {
        try {
            ApplicationInfo app = getPackageManager().getApplicationInfo(pkg, 0);
            return getPackageManager().getApplicationLabel(app).toString();
        } catch (Exception e) {
            return pkg;
        }
    }
    
    private void addLog(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (logText != null) {
                    logText.append(msg + "\n");
                    // Auto scroll ke bawah
                    scrollView.post(new Runnable() {
                        @Override
                        public void run() {
                            scrollView.fullScroll(View.FOCUS_DOWN);
                        }
                    });
                }
            }
        });
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        deactivateWarMode();
        // Log bakal ilang otomatis karena TextView di-destroy
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        // Optional: Kasih tau user kalo balik ke app
        if (logText != null && isActive) {
            addLog("\n📱 Kembali ke app - War Mode masih ON");
            addLog("💡 Matikan toggle kalo mau berhenti");
        }
    }
}